from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
CORS(app)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.route("/upload", methods=["POST"])
def upload():
    user_id = request.form.get("user_id")
    caption = request.form.get("caption")
    accounts = request.form.get("accounts", "").split(",")
    media_file = request.files.get("media")

    if not media_file:
        return jsonify({"error": "No media uploaded."}), 400

    filename = secure_filename(media_file.filename)
    file_path = os.path.join(UPLOAD_DIR, filename)
    media_file.save(file_path)

    return jsonify({
        "message": "File uploaded successfully.",
        "file": file_path,
        "caption": caption,
        "accounts": accounts
    })

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5001)
