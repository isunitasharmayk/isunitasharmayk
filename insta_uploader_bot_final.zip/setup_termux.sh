#!/data/data/com.termux/files/usr/bin/bash

echo "=== Instagram Uploader Bot: Auto Setup ==="

# Update & install dependencies
pkg update -y && pkg upgrade -y
pkg install -y python git nodejs clang libjpeg-turbo

# Python dependencies
pip install flask flask-cors python-telegram-bot werkzeug

# Navigate to project directory
cd insta_uploader_bot

# Start Flask API in background
echo "Starting Flask API on port 5001..."
nohup python dashboard_api_termux.py > flask.log 2>&1 &

# Start Telegram bot
echo "Starting Telegram bot..."
cd bot
nohup python main.py > bot.log 2>&1 &

# Setup React frontend
cd ../web-dashboard
if [ ! -d "node_modules" ]; then
  echo "Installing React dependencies..."
  npm install
fi

echo "Starting React app on port 3000..."
nohup npm start > react.log 2>&1 &

echo "=== All services are running in background ==="
echo "You can open your bot and use /dashboard to access the uploader panel."
